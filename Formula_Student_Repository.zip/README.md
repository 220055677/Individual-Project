# Formula Student Repository

This repository is designed to manage all documentation and records for the Formula Student team.

## Structure Overview
- **Technical Documentation**: CAD files, test results, specifications.
- **Project Records**: Meeting notes, design rationales, troubleshooting logs.
- **Competition Records**: Results, rule updates, event-specific details.
- **Media and Communication**: Images, videos, social media drafts.
- **User Manuals and Templates**: Templates, onboarding guides, change logs.

Refer to the individual folder `README.md` files for more details.