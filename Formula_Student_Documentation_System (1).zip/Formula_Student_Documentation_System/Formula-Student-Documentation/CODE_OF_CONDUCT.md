
# Code of Conduct

This Code of Conduct applies to all contributors.

## Expected Behavior

- Be respectful and inclusive.
- Provide constructive feedback.
- Assume positive intent in discussions.

## Unacceptable Behavior

- Harassment of any kind.
- Discriminatory comments or actions.
