# Design Decision Template
**Date**:
**Decision**:
**Rationale**:
**Evidence**:
**Stakeholders**:
