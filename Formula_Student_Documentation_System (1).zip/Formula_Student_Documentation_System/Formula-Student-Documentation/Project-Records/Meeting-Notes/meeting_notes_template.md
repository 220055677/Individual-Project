# Meeting Notes Template
**Date**:
**Attendees**:
**Agenda**:
**Key Points Discussed**:
**Action Items**:
