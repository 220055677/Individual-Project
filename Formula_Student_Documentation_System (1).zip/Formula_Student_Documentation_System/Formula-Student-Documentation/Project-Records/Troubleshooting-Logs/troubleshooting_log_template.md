# Troubleshooting Log Template
**Date**:
**Issue**:
**Cause**:
**Solution**:
**Outcome**:
